----------------
-- PITMAN.BAS --
----------------
PITMAN is a puzzle game for the Sharp MZ-700. It was originally created by
Yutaka Isokawa and the BASIC listing was published in Japanese magazine "Oh!MZ"
in August of 1985.

The original listing only worked with HU-BASIC and it was adapted by Sylvain 
Bizoirre to work with S-BASIC, which was a more commonly used BASIC version. 
HU-BASIC specific commands were replaced, for example LOCATE is replaced with 
CURSOR, and CHARACTER$ is replaced with PEEK($D000). This adapted listing was 
published in the November issue of a French magazine "Sharpentiers".

The PITMAN.BAS file contains the adapted listing.

--------------
-- EMULATOR --
--------------
The PITMAN.BAS file can be used with the MZxEmu emulator by Michael Franzen. 

1) Start MZxEmu
2) In the MZxEmu window, click on MZ700
3) In the MZxEmu window, click on the BASIC button, it should load
   "BASIC INTERPRETER 1Z-013B"
4) In the emulator type LOAD and press enter, it will display "PLAY"
6) In the MZxEmu window, click on the PLAY button
7) An "Open file" dialog should appear, select the file PITMAN.BAS
8) The emulator should display FOUND "PITMAN" and then LOADING "PITMAN"
9) Wait until loading is ready, the emulator will display "Ready".
10) In the emulator type RUN and press enter

Note: the game takes about a minute to initialise the 50 levels.

--------------
-- GAMEPLAY --
--------------
From the title screen press:
SPACE  - to start the game
M      - to go to monitor (see below)
1,2..9 - to start on level 5,10..45

Pitman is a puzzle game and the goal of each level is to collect all heaps of 
gold. The player can only pick up gold by walking onto it from the left or 
right, not from below or above. The player can use ladders, push boulders and
dig through dirt.

Move the pitman with the cursor keys. If you are stuck on a level you can skip 
or reset which will cost one life. At any time during the game you can press:
S - to skip a level
P - to go back a level
M - to reset the current level 

-------------
-- MONITOR --
-------------
During the game you can press E to go to the Pitman monitor, which is similar to 
the console found in modern FPS games. 

Here you can type one of the following letters: 
A - Help (in French)
J - Select a level and return to game
L - Load levels from tape
S - Save levels to tape
E - Clear a level
D - Level editor
I - Data out/in
R - Reset game and re-initialise all levels (this will overwrite all changes
made with the level editor)

------------------
-- LEVEL EDITOR --
------------------
Move the editor cursor around using the cursor keys. Press 1..7 to place the 
following at the cursor:
1 - Empty/erase
2 - Ladder
3 - Gold
4 - Dirt
5 - Boulder
6 - Wall
7 - Pitman (player start position)

While editing you can press S and P to skip levels forward and back. Press M to 
go back to the monitor, from where you can choose to play the edited level. 

-----------
-- NOTES --
-----------
The scan of Sharpentiers magazine #15 was found here: 
http://www.abandonware-magazines.org/affiche_mag.php?mag=125&page=1 

I have a lot of respect for people who managed to get a magazine listing like 
this to actually work back in the day. While typing in the entire listing from 
the magazine, I ran into some of the typical problems:

First and foremost, entering the DATA lines was quite a challenge to put it 
mildly. You had to take on the chore of manually entering 4KB+ of data (phew!) 
which contains the layouts of all the 50 levels. The program checks if all the 
DATA lines were entered exactly as printed in the magazine. It does a very 
rudimentary data integrity check at line 60, using only one single checksum 
(Y=7837). This means that in the very likely event that you entered a few digits 
incorrectly, all the program would display was "error in the DATA's". It doesn't 
give a clue as to which line the error might be, so you'd have to re-check all 
4400 data digits(!!). Knowing that this would be published as a type-in listing, 
Bizoirre could have included a checksum for each line of data. If the user made 
a mistake then, the program could give a much more helpful message, for example 
"error in DATA line 5".

Secondly, the MZ-700 has lots of graphics characters and sometimes it's hard to 
determine which character is meant. Most notably, the top middle character for 
drawing the gold heaps (line 2050) is important because it is used to identify 
where there is a gold heap. In several places the program checks this character 
to see if it is value $7E, which is GRP+SHIFT+3 and not characters GRP+2 or 
GRP+5 which I initially tried.

Third problem was that once you started the program with the RUN command there 
is, as far as I know, no way to quit back to the BASIC prompt. Maybe there is a 
CTRL+BREAK key combination I'm unaware of, but at one time I was testing some 
changes only to realise that I could not go back and save it to tape. Luckily I 
only lost about 10 minutes of work. This is why I added line 121, to quit from
the title screen by pressing Q.

Bizoirre added a timer function to see how long it took you to solve a level,
this was not present in the original version. Incidentally, the Gameboy version
also includes a timer.

In the original version, the monitor had an option "data out/in" but it was 
omitted in the Sharpentiers version, maybe due to time restrictions. It allowed 
users to output or input levels via 46 character passwords. This was probably 
intended for users to exchange levels more easily. This option is now added 
again, see code lines 1121, 1251 and starting at 3000.

Finally, there was a mistake in the adaptation in line 410. The line evaluates
wether the player can move up to a destination location, see pseudo code below.
Oh!MZ       : IF DestIsEmpty OR (DestIsLadder AND StandOnLadder) THEN DoMoveUp
Sharpentiers: IF StandOnLadder AND (DestIsEmpty OR DestIsLadder) THEN DoMoveUp
In the Oh!MZ version, the player could jump up and fall right back down,
triggering the gravity for the column the player was standing in. However, in
the Sharpentiers version the player couldn't jump, making level 11 unsolvable.
In the PITMAN.BAS file in this archive this bug is fixed.

-------------
-- HISTORY --
-------------

16-jul-2012 - first release
21-jul-2012 - "jump" bugfix, added data out/in option, minor corrections

questions, comments: Bas de Reuver - bdr1976@gmail.com
